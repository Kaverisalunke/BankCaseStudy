package com.bs.bank;

public class ViewStatus {

	private String email;
	private String newnum;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNewnum() {
		return newnum;
	}
	public void setNewnum(String newnum) {
		this.newnum = newnum;
	}
	
}
