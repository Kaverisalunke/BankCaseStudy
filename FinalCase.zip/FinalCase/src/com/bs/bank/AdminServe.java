package com.bs.bank;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;

@Path("/adminserve")
public class AdminServe {

	@GET
	@Path("/alogin/{username}/{password}")
	public String chkLogin(@PathParam("username") String username, @PathParam("password") String password) {
		String sta = "[{\"status\":\"Login Failure\"}]";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("sozoBank");
		DBCollection coll = db.getCollection("admin");
		DBCursor cursor = coll.find();
		String nPass = "";
		while (cursor.hasNext()) {
			BasicDBObject obj = new BasicDBObject();
			obj = (BasicDBObject) cursor.next();
			String nUname = (String) obj.get("username");
			if (nUname.equals(username)) {
				nPass = (String) obj.get("password");
			}
		}
		if (password.equals(nPass)) {
			sta = "[{\"status\":\"Login Success\"}]";
		}
		return sta;
	}
/***
 * session maintain
 */
//	@GET
//	@Path("/uplogin/{uname}")
//	public String uplogin(@PathParam("uname") String uname) {
//		String sta = "[{\"status\":\"PENDING\"}]";
//		MongoClient client = new MongoClient("localhost", 27017);
//		DB db = client.getDB("sozoBank");
//		DBCollection coll = db.getCollection("utab");
//		BasicDBObject obj=new BasicDBObject("uname",uname);
//		DBCursor cursor=coll.find();
//		while(cursor.hasNext()) {
//			BasicDBObject obj2=new BasicDBObject();
//			obj2=(BasicDBObject)cursor.next();
//			String ouname=(String)obj2.get("uname");
//			BasicDBObject obj3=new BasicDBObject("uname",ouname);
//			coll.update(obj3, obj);
//			sta = "[{\"status\":\"UPDATED\"}]";
//			
//		}
//		return sta;
//	}
	
	
//	/***
//	 * not important
//	 * @param email
//	 * @param mobile
//	 * @return
//	 */
//	@GET
//	@Path("/upmobile/{email}/{mobile}")
//	public String upMobile(@PathParam("email") String email, @PathParam("mobile") String mobile) {
//		String sta = "[{\"status\":\"PENDING\"}]";
//		MongoClient client = new MongoClient("localhost", 27017);
//		DB db = client.getDB("sozoBank");
//		DBCollection coll = db.getCollection("upsMobile");
//		BasicDBObject obj = new BasicDBObject("email", email);
//		obj.append("newnum", mobile);
//		coll.insert(obj);
//		return sta;
//	}
	
	
	@GET
	@Path("/retView")
	public String retView() {
		String sta = "[{\"status\":\"NOVIEW\"}]";
		List<ViewStatus> ll=new ArrayList<>();
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("sozoBank");
		DBCollection coll = db.getCollection("upsMobile");
		DBCursor cursor=coll.find();
		while(cursor.hasNext()) {
			BasicDBObject obj=new BasicDBObject();
			obj=(BasicDBObject)cursor.next();
			String nemail=(String)obj.get("email");
			String newnum=(String)obj.get("newnum");
			ViewStatus vsta=new ViewStatus();
			vsta.setEmail(nemail);
			vsta.setNewnum(newnum);
			ll.add(vsta);
		}
		ObjectMapper mapper=new ObjectMapper();
		try {
			sta=mapper.writeValueAsString(ll);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sta;
	}
	
	
	
	

	@GET
	@Path("/vermobile/{email}")
	public String verMobile(@PathParam("email") String email) {
		String sta = "[{\"status\":\"VERIFIED\"}]";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("sozoBank");
		DBCollection coll = db.getCollection("upsMobile");
		String nMobile = null;
		DBCursor cursor = coll.find();
		while (cursor.hasNext()) {
			BasicDBObject obj = new BasicDBObject();
			obj = (BasicDBObject) cursor.next();
			String nEmail = (String) obj.get("email");
			if (nEmail.equals(email)) {
				nMobile = (String) obj.get("newnum");
			}
		}
		if (nMobile != null) {
			DBCollection coll2 = db.getCollection("accHolder");
			BasicDBObject obj3 = new BasicDBObject("email", email);
			DBCursor cursor2 = coll2.find(obj3);
			while (cursor2.hasNext()) {
				BasicDBObject obj4 = new BasicDBObject();
				obj4 = (BasicDBObject) cursor2.next();
				double nhid = Double.valueOf(obj4.get("hid").toString());
				String nname = (String) obj4.get("name");
				String nemail = (String) obj4.get("email");
				String nmobile1 = (String) obj4.get("mobile");
				String ndob = (String) obj4.get("dob");
				String naddress = (String) obj4.get("address");
				String ngender = (String) obj4.get("gender");
				Object naccnum =  obj4.get("accno");
				float namount =Float.valueOf(obj4.get("amount").toString());
				BasicDBObject obja = new BasicDBObject("hid", nhid);
				obja.append("name", nname).append("email", nemail).append("mobile", nMobile).append("dob", ndob)
						.append("address", naddress).append("gender", ngender).append("amount", namount)
						.append("accno", Double.valueOf(naccnum.toString()));
				coll2.update(obj3, obja);
				BasicDBObject obj6=new BasicDBObject("email",email);
				coll.remove(obj6);
				
			}
		} else {
			sta = "[{\"status\":\"NORECORD\"}]";
		}

		return sta;
	}
	
//	
//	/***
//	 * correct method running
//	 * @return
//	 */
//	
//	@GET
//	@Path("/vermobile")
//	public String verMobile2() {
//		
//		String sta = "[{\"status\":\"VERIFIED\"}]";
//		MongoClient client = new MongoClient("localhost", 27017);
//		DB db = client.getDB("sozoBank");
//		DBCollection coll = db.getCollection("upsMobile");
//		String nMobile = null;
//		DBCursor cursor = coll.find();
//		while (cursor.hasNext()) {
//			BasicDBObject obj = new BasicDBObject();
//			obj = (BasicDBObject) cursor.next();
//			String nEmail = (String) obj.get("email");
//			
//			nMobile = (String) obj.get("newnum");
//			
//		}
//		if (nMobile != null) {
//			DBCollection coll2 = db.getCollection("accHolder");
//			//BasicDBObject obj3 = new BasicDBObject("email", email);
//			DBCursor cursor2 = coll2.find();
//			while (cursor2.hasNext()) {
//				BasicDBObject obj4 = new BasicDBObject();
//				obj4 = (BasicDBObject) cursor2.next();
//				double nhid = Double.valueOf(obj4.get("hid").toString());
//				String nname = (String) obj4.get("name");
//				String nemail = (String) obj4.get("email");
//				String nmobile1 = (String) obj4.get("mobile");
//				String ndob = (String) obj4.get("dob");
//				String naddress = (String) obj4.get("address");
//				String ngender = (String) obj4.get("gender");
//				Object naccnum =  obj4.get("accno");
//				float namount = Float.valueOf(obj4.get("amount").toString());
//				
//				
//				
//				
//				
//			}
//		} else {
//			sta = "[{\"status\":\"NORECORD\"}]";
//		}
//
//		return sta;
//	}
//
//	
	
	
	
	@GET
	@Path("/transamount/{email}/{amount}")
	public String transAmount(@PathParam("email") String email,@PathParam("amount") double amount) {
		String sta = "[{\"status\":\"NOTTRANSFFERED\"}]";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("sozoBank");
		DBCollection coll = db.getCollection("upsMobile");
		if (email != null) {
			DBCollection coll2 = db.getCollection("accHolder");
			BasicDBObject obj3 = new BasicDBObject("email", email);
			DBCursor cursor2 = coll2.find(obj3);
			while (cursor2.hasNext()) {
				BasicDBObject obj4 = new BasicDBObject();
				obj4 = (BasicDBObject) cursor2.next();
		double nhid = Double.valueOf(obj4.get("hid").toString());
			
				String nname = (String) obj4.get("name");
				String nemail = (String) obj4.get("email");
				String nmobile1 = (String) obj4.get("mobile");
				String ndob = (String) obj4.get("dob");
				String naddress = (String) obj4.get("address");
				String ngender = (String) obj4.get("gender");
				String naccnum =  (String)obj4.get("accno");
				Object namount = obj4.get("amount");
				double aa=Double.valueOf(namount.toString());
				aa=aa+amount;
				BasicDBObject obja = new BasicDBObject("hid", nhid);
				obja.append("name", nname).append("email", nemail).append("mobile", nmobile1).append("dob", ndob)
						.append("address", naddress).append("gender", ngender).append("amount", aa)
						.append("accno", naccnum);
				coll2.update(obj3, obja);
				sta = "[{\"status\":\"TRANSFFERED\"}]";
			}
		} else {
			sta = "[{\"status\":\"NORECORD\"}]";
		}
		return sta;
	}
	
	@GET
	@Path("/sendamount/{email}/{temail}/{amt}")
	public String sendAmount(@PathParam("email") String email,@PathParam("temail") String temail,@PathParam("amt") float amt)
	{
		String sta = "[{\"status\":\"NOTTRANSFFERED\"}]";
		//Amount deduction
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("sozoBank");
		
		if (email != null) {
			DBCollection coll2 = db.getCollection("accHolder");
			BasicDBObject obj3 = new BasicDBObject("email", email);
			DBCursor cursor2 = coll2.find(obj3);
			while (cursor2.hasNext()) {
				BasicDBObject obj4 = new BasicDBObject();
				obj4 = (BasicDBObject) cursor2.next();
				double nhid = Double.valueOf(obj4.get("hid").toString());
				String nname = (String) obj4.get("name");
				String nemail = (String) obj4.get("email");
				String nmobile1 = (String) obj4.get("mobile");
				String ndob = (String) obj4.get("dob");
				String naddress = (String) obj4.get("address");
				String ngender = (String) obj4.get("gender");
				String naccnum = (String) obj4.get("accno");
				Object namount = obj4.get("amount");
				float aa=Float.valueOf(namount.toString());
				aa=aa-amt;
				BasicDBObject obja = new BasicDBObject("hid", nhid);
				obja.append("name", nname).append("email", nemail).append("mobile", nmobile1).append("dob", ndob)
						.append("address", naddress).append("gender", ngender).append("amount", aa)
						.append("accno", naccnum);
				coll2.update(obj3, obja);
				sta = "[{\"status\":\"TRANSFFERED\"}]";
			}
		} else {
			sta = "[{\"status\":\"NORECORD\"}]";
		}
		
		//Amount addition
		
		if (temail != null) {
			DBCollection coll2 = db.getCollection("accHolder");
			BasicDBObject obj3 = new BasicDBObject("email", temail);
			DBCursor cursor2 = coll2.find(obj3);
			while (cursor2.hasNext()) {
				BasicDBObject obj4 = new BasicDBObject();
				obj4 = (BasicDBObject) cursor2.next();
				double nhid = Double.valueOf(obj4.get("hid").toString());
				String nname = (String) obj4.get("name");
				//String nemail = (String) obj4.get("email");
				String nmobile1 = (String) obj4.get("mobile");
				String ndob = (String) obj4.get("dob");
				String naddress = (String) obj4.get("address");
				String ngender = (String) obj4.get("gender");
				String naccnum = (String) obj4.get("accno");
				Object namount = obj4.get("amount");
				float aa=Float.valueOf(namount.toString());
				aa=aa+amt;
				BasicDBObject obja = new BasicDBObject("hid", nhid);
				obja.append("name", nname).append("email", temail).append("mobile", nmobile1).append("dob", ndob)
						.append("address", naddress).append("gender", ngender).append("amount", aa)
						.append("accno", naccnum);
				coll2.update(obj3, obja);
				sta = "[{\"status\":\"TRANSFFERED\"}]";
			}
		} else {
			sta = "[{\"status\":\"NORECORD\"}]";
		}
		return sta;
	}
	
	
	
	
	
	@GET
	@Path("/viewbal/{email}")
	public String retBal(@PathParam("email") String email) {
		String sta = "[{\"balance\":\"NOBALANCE\"}]";
		List<ModelClass> ll=new ArrayList<>();
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("sozoBank");
		DBCollection coll=db.getCollection("accHolder");
		DBCursor cursor=coll.find();
		while(cursor.hasNext()) {
			BasicDBObject obj2=new BasicDBObject();
			obj2=(BasicDBObject)cursor.next();
			String email1=(String)obj2.get("email");
			if(email.equals(email1)) {
			Object a=obj2.get("amount");
			float amt=Float.valueOf(a.toString());
			ModelClass cls=new ModelClass();
			cls.setAmount(amt);
			ll.add(cls);
		}
		
	}
		ObjectMapper mapper=new ObjectMapper();
		try {
			sta=mapper.writeValueAsString(ll);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sta="[{\"balance\":\"BALANCE\"}]";
		}
	
		return sta;

	}

}
