package com.bs.bank;

public class StateCls1 {

	private float amount;
	private double accno;

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public double getAccno() {
		return accno;
	}

	public void setAccno(double accno) {
		this.accno = accno;
	}
}
