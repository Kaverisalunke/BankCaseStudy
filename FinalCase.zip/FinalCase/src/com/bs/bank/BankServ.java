package com.bs.bank;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;

@Path("/bs")
public class BankServ {
	
	@GET
	@Path("/regist/{name}/{username}/{password}/{email}/{mobile}/{dob}/{address}/{gender}")
	public String register(@PathParam("name") String name,@PathParam("username") String username,@PathParam("password") String password,@PathParam("email") String email,@PathParam("mobile") String mobile,@PathParam("dob") String dob,@PathParam("address") String address,@PathParam("gender") String gender)
	{
		String cc="Done";
		String status="[{\"status\":\"0\"}]";
		MongoClient client=new MongoClient("localhost",27017);
		DB db=client.getDB("sozoBank");
		DBCollection coll=db.getCollection("accHolder");
		DBCursor cursor=coll.find();
		int i=0;
		while(cursor.hasNext()) {
			BasicDBObject objj=(BasicDBObject)cursor.next();
			i++;
			String aa=objj.getString("_id");
			aa=aa.substring(18, 24);
			cc=aa;
		}
		int hid=++i;
		DBCollection coll2=db.getCollection("Login");
		BasicDBObject objj=new BasicDBObject("hid",hid);
		objj.append("username",username);
		objj.append("password", password);
		coll2.insert(objj);
		BasicDBObject obj=new BasicDBObject("hid",hid);
		obj.append("name", name);
		obj.append("email", email);
		obj.append("mobile", mobile);
		obj.append("dob", dob);
		obj.append("address", address);
		obj.append("gender", gender);
		obj.append("amount", 0.0f);
		obj.append("accno", cc);
		coll.insert(obj);
		status="[{\"status\":\"1\"}]";
		return status;
	}
	

	@GET
	@Path("/ulogin/{uname}/{pwd}")
	public String ulogin(@PathParam("uname") String uname,@PathParam("pwd") String pwd) {
		
		String finStr="";
		finStr="[{\"status\":\"failure\"}]";
		MongoClient client=new MongoClient("localhost",27017);
		DB db=client.getDB("sozoBank");
		DBCollection coll=db.getCollection("Login");
		DBCursor cursor=coll.find();
		String uuPass="";
		while(cursor.hasNext()) {
			BasicDBObject obj=new BasicDBObject();
			obj=(BasicDBObject)cursor.next();
			String ugname=(String)obj.get("username");
			String pass=(String)obj.get("password");
			if(uname.equals(ugname)) {
				uuPass=pass;
				break;
			}
		}
		if(uuPass.equals(pwd)) {
			
			finStr="[{\"status\":\"success\"}]";
			
		}
		return finStr;
	}
	
	@GET
	@Path("/getStmt/{email}")
	public String getStmt(@PathParam("email") String email) {
		String finStr="[{\"status\":\"0\"}]";
		List<StateCls> ll=new ArrayList<>();
		MongoClient client=new MongoClient("localhost",27017);
		DB db=client.getDB("sozoBank");
		DBCollection coll=db.getCollection("accHolder");
		DBCursor cursor=coll.find();
		while(cursor.hasNext()) {
			BasicDBObject obj=new BasicDBObject();
			obj=(BasicDBObject)cursor.next();
			String eemail=(String)obj.get("email");
			if(email.equals(eemail)) {
			String mob=(String)obj.get("mobile");
			String address2=(String)obj.get("address");
			Object o=obj.get("amount");
			float amt=Float.valueOf(o.toString());
			StateCls cls=new StateCls();
			cls.setMobile(mob);
			cls.setAddress(address2);
			cls.setAmount(amt);
			ll.add(cls);
			}
		}
		ObjectMapper mapper=new ObjectMapper();
		try {
			finStr=mapper.writeValueAsString(ll);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			finStr="[{\"status\":\"1\"}]";
		}
		return finStr;
	}
	
	
	@GET
	@Path("/insNum/{email}/{newnum}")
	public String insNum(@PathParam("email") String email,@PathParam("newnum") String newnum) {
		String finStr="[{\"status\":\"pending\"}]";
		MongoClient client=new MongoClient("localhost",27017);
		DB db=client.getDB("sozoBank");
		DBCollection coll=db.getCollection("upsMobile");
		BasicDBObject obj=new BasicDBObject("email",email);
	
		obj.append("newnum", newnum);
		coll.insert(obj);
		return finStr;
	}
	
	
//	@GET
//	@Path("/chgPass/{username}/{opass}/{npass}")
//	public String chgPass(@PathParam("username") String username, @PathParam("opass") String opass,@PathParam("npass") String npass)
//	{
//		String sta="[{\"status\":\"success\"}]";
//		MongoClient client=new MongoClient("localhost",27017);
//		DB db=client.getDB("sozoBank");
//		DBCollection coll=db.getCollection("Login");
//		BasicDBObject whereCond=new BasicDBObject("username",username);
//		BasicDBObject obj2=new BasicDBObject("username",username);
//		obj2.append("password", npass);
//		coll.update(whereCond, obj2);
//		return sta;
//	}
	
	
	@GET
	@Path("/chgPass/{username}/{opass}/{npass}")
	public String chgPass(@PathParam("username") String username, @PathParam("opass") String opass,@PathParam("npass") String npass)
	{
		String sta="[{\"status\":\"success\"}]";
		MongoClient client=new MongoClient("localhost",27017);
		DB db=client.getDB("sozoBank");
		DBCollection coll=db.getCollection("Login");
		BasicDBObject whereCond=new BasicDBObject("username",username);
		
		
		double h=0.0;
		DBCursor cur = coll.find();
		while(cur.hasNext()) {
			BasicDBObject o = new BasicDBObject();
			o = (BasicDBObject) cur.next();
			String uname = (String) o.get("username");
			if(uname!=null) {
				if(uname.equals(username)) {
//					h = (double) o.get("hid");
					h=  Double.valueOf(o.get("hid").toString());
				}
			}
		}
		
		
		BasicDBObject obj2=new BasicDBObject("hid", h);
		obj2.append("username",username);
		obj2.append("password", npass);
		coll.update(whereCond, obj2);
		return sta;
	}
	
	


	@GET
	@Path("/viewbal/{email}")
	public String retBal(@PathParam("email") String email) {
		String sta = "[{\"balance\":\"NOBALANCE\"}]";
		List<StateCls1> ll=new ArrayList<>();
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("sozoBank");
		DBCollection coll=db.getCollection("accHolder");
		DBCursor cursor=coll.find();
		while(cursor.hasNext()) {
			BasicDBObject obj2=new BasicDBObject();
			obj2=(BasicDBObject)cursor.next();
			String email1=(String)obj2.get("email");
			if(email.equals(email1)) {
			Object a=obj2.get("amount");
			float amt=Float.valueOf(a.toString());
			StateCls1 cls=new StateCls1();
			cls.setAmount(amt);
			ll.add(cls);
		}
		
	}
		ObjectMapper mapper=new ObjectMapper();
		try {
			sta=mapper.writeValueAsString(ll);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sta="[{\"balance\":\"BALANCE\"}]";
		}
	
		return sta;

	}
	
//	@GET
//	@Path("/transamount/{email}/{amount}")
//	public String transAmount(@PathParam("email") String email,@PathParam("amount") float amount) {
//		System.out.println("Inside the emthod");
//		String sta = "[{\"status\":\"NOTTRANSFFERED\"}]";
//		MongoClient client = new MongoClient("localhost", 27017);
//		DB db = client.getDB("sozoBank");
//		
//		if (email != null) {
//			DBCollection coll2 = db.getCollection("accHolder");
//			BasicDBObject obj3 = new BasicDBObject("email", email);
//			DBCursor cursor2 = coll2.find(obj3);
//			while (cursor2.hasNext()) {
//				
//				BasicDBObject obj4 = new BasicDBObject();
//				obj4 = (BasicDBObject) cursor2.next();
//				double nhid=Double.valueOf(obj4.get("hid").toString());
//				String nname = (String) obj4.get("name");
//				String nemail = (String) obj4.get("email");
//				String nmobile1 = (String) obj4.get("mobile");
//				String ndob = (String) obj4.get("dob");
//				String naddress = (String) obj4.get("address");
//				String ngender = (String) obj4.get("gender");
//				Object naccnum =  obj4.get("accno");
//				Object namount = obj4.get("amount");
//			
//				float aa=Float.valueOf(namount.toString());
//				aa=aa+amount;
//				BasicDBObject obja = new BasicDBObject("hid", nhid);
//				obja.append("name", nname).append("email", nemail).append("mobile", nmobile1).append("dob", ndob)
//						.append("address", naddress).append("gender", ngender).append("amount", aa)
//						.append("accno", Double.valueOf(naccnum.toString()));
//		
//				
//				coll2.update(obj3, obja);
//				sta = "[{\"status\":\"TRANSFFERED\"}]";
//			}
//		} else {
//			sta = "[{\"status\":\"NORECORD\"}]";
//		}
//		return sta;
//	}


	@GET
	@Path("/transamount/{email}/{amount}")
	public String transAmount(@PathParam("email") String email,@PathParam("amount") float amount) {
		System.out.println("Inside the emthod");
		String sta = "[{\"status\":\"NOTTRANSFFERED\"}]";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("sozoBank");
		
		if (email != null) {
			DBCollection coll2 = db.getCollection("accHolder");
			BasicDBObject obj3 = new BasicDBObject("email", email);
			DBCursor cursor2 = coll2.find(obj3);
			while (cursor2.hasNext()) {
				
				BasicDBObject obj4 = new BasicDBObject();
				obj4 = (BasicDBObject) cursor2.next();
				double nhid=Double.valueOf(obj4.get("hid").toString());
				String nname = (String) obj4.get("name");
				String nemail = (String) obj4.get("email");
				String nmobile1 = (String) obj4.get("mobile");
				String ndob = (String) obj4.get("dob");
				String naddress = (String) obj4.get("address");
				String ngender = (String) obj4.get("gender");
				String naccnum =  (String) obj4.get("accno");
				Object namount = obj4.get("amount");
			
				float aa=Float.valueOf(namount.toString());
				aa=aa+amount;
				BasicDBObject obja = new BasicDBObject("hid", nhid);
				obja.append("name", nname).append("email", nemail).append("mobile", nmobile1).append("dob", ndob)
						.append("address", naddress).append("gender", ngender).append("amount", aa)
						.append("accno", naccnum);
		
				
				coll2.update(obj3, obja);
				sta = "[{\"status\":\"TRANSFFERED\"}]";
			}
		} else {
			sta = "[{\"status\":\"NORECORD\"}]";
		}
		return sta;
	}

	
	
	

	/***
	 * to get acc no
	 * @param username
	 * @return
	 */
	@GET
	@Path("/viewANum/{username}")
	public String viewANum(@PathParam("username") String username)
	{
		String sta = "[{\"status\":\"NONAME\"}]";
		MongoClient client = new MongoClient("localhost", 27017);
		DB db = client.getDB("sozoBank");
		DBCollection coll = db.getCollection("Login");
		DBCollection coll2=db.getCollection("accHolder");
		DBCursor cursor1=coll.find();
		double hid=0;
		while(cursor1.hasNext()) {
			BasicDBObject obj=new BasicDBObject();
			obj=(BasicDBObject)cursor1.next();
			String nUName=(String)obj.get("username");
			if(nUName.equals(username)) {
			  hid=Double.valueOf(obj.get("hid").toString());
			}
		}
		DBCursor cursor2=coll2.find();
		Object acnum1="";
		while(cursor2.hasNext()) {
			BasicDBObject obj22=new BasicDBObject();
			obj22=(BasicDBObject)cursor2.next();
			double hid2=Double.valueOf(obj22.get("hid").toString());
			if(hid2 != 0) {
				if(hid2==hid) {
					acnum1=obj22.get("accno");
					sta="[{\"status\":\""+acnum1.toString().trim()+"\"}]";
					//sta="[{\"status\":\"NONAME\"}]";
					}
			}
		}
		return sta;
	}

	
}
