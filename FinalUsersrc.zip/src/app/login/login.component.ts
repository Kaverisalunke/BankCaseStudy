import { BnkserviceService } from '../bnkservice.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import {Http , Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[BnkserviceService]
})
export class LoginComponent implements OnInit {

  username:String;
  password:String;
  httpdata:any[];
  status:String;
  
  constructor(private iserve:BnkserviceService,private router:Router,private http:Http) { }
  
  onLogin(form:NgForm){
  
    this.httpdata=this.iserve.ulogin(this.username,this.password);
    if(this.httpdata != null){
      let sta=this.httpdata[0]['status'];
      if(sta =='success'){
        this.router.navigateByUrl('/afterlogin');
      }
      else{
this.datadisplay();
       // console.log(this.httpdata);
      }
    }
  }

  datadisplay(){
    this.status="login unsuccessful";
    return this.status;
  }

  ngOnInit() {
  }

}
