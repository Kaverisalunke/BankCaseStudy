import { BnkserviceService } from '../bnkservice.service';
import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-accountbalance',
  templateUrl: './accountbalance.component.html',
  styleUrls: ['./accountbalance.component.css'],
  providers:[BnkserviceService]
})
export class AccountbalanceComponent implements OnInit {
httpdata:any[];
  email:String;
  amount:number;
  constructor(private iserve:BnkserviceService, private router:Router, private http:Http) { }

  onSubmit(){
   this.httpdata=this.iserve.viewbal(this.email);  
  }
  
  ngOnInit() {
  }
   btnClick=function(){
    this.router.navigateByUrl('/afterlogin');
  }

}
