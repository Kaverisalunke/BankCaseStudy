

import { BnkserviceService } from '../bnkservice.service';
import { Component, OnInit } from '@angular/core';
import {HttpModule, Http} from '@angular/http';
import 'rxjs/add/operator/map';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ministatement',
  templateUrl: './ministatement.component.html',
  styleUrls: ['./ministatement.component.css']
  
})
export class MinistatementComponent implements OnInit {
 httpdata:any[];
  email:String;
  mobile:String;
  amount:number;
  address:String;
  constructor(private iserve:BnkserviceService, private router:Router, private http:Http) {}
  onSubmit(form:NgForm){
      this.httpdata=this.iserve.getminsmt(this.email);
      
    }

  ngOnInit() {
    
   
  }

  btnClick=function(){
    this.router.navigateByUrl('/afterlogin');
  }
}
