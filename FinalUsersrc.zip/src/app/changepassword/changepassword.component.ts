import { BnkserviceService } from '../bnkservice.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Http } from '@angular/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css'],
  providers:[BnkserviceService]
})
export class ChangepasswordComponent implements OnInit {

  username:String;
  opass:String;
  npass:String;
  httpdata:any[];
  status:String;
  constructor(private iserve:BnkserviceService, private router:Router, private http:Http) { }
  
 onSubmit(){
   this.httpdata=this.iserve.chngPassword(this.username,this.opass, this.npass);
  if(this.httpdata != null){
      let sta=this.httpdata[0]['status'];
      if(sta =='success'){
//        this.router.navigateByUrl('/afterlogin');
        this.datadisplay();
     
      }
     
  }
  }
  
  datadisplay(){
    this.status="Your password is changed";
    return this.status;
  }
  ngOnInit() {
  }

  btnClick=function(){
    this.router.navigateByUrl('/afterlogin');
  }
   
     displaydata(data) {this.httpdata = data;}
   
}
