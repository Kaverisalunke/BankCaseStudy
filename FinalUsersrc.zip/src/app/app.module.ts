import { AboutusComponent } from './aboutus/aboutus.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule} from '@angular/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {Http, Response } from '@angular/http';
import { AppComponent } from './app.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';

import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { ServicesComponent } from './services/services.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';

import { AfterloginComponent } from './afterlogin/afterlogin.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { ChangemobileComponent } from './changemobile/changemobile.component';
import { TransferamountComponent } from './transferamount/transferamount.component';
import { MinistatementComponent } from './ministatement/ministatement.component';
import { AccountbalanceComponent } from './accountbalance/accountbalance.component';
import { BnkserviceService } from './bnkservice.service';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    ServicesComponent,
    AboutusComponent,
    ContactusComponent,
    RegistrationComponent,
    ForgotpasswordComponent,
    
    AfterloginComponent,
    ChangepasswordComponent,
    ChangemobileComponent,
    TransferamountComponent,
    MinistatementComponent,
    AccountbalanceComponent

  ],
  imports: [
    RouterModule.forRoot([
    {
        path:'home',
        component:HomeComponent
    }, 
     {
        path:'',
        redirectTo: '/home',pathMatch: 'full'
    }, 
    {
        path:'aboutus',
        component:AboutusComponent
    },
    {
        path:'contactus',
        component: ContactusComponent
    },
    {
        path:'login',
        component:LoginComponent
    },
    {
        path:'services',
        component:ServicesComponent
    },
    {
        path:'registration',
        component:RegistrationComponent
    },
    {
        path:'afterlogin',
        component: AfterloginComponent
    },   
    {
        path:'forgotpassword',
        component: ForgotpasswordComponent
    },
    {
        path:'changepassword',
        component: ChangepasswordComponent
    },
    {
        path:'changemobile',
        component: ChangemobileComponent
    },
    
    {
        path:'transferamount',
        component: TransferamountComponent
    },
    {
        path:'ministatement',
        component: MinistatementComponent
    },
    {
        path:'accountbalance',
        component: AccountbalanceComponent
    }
    ]),
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [BnkserviceService],
  bootstrap: [AppComponent]
})
  
  
  
export class AppModule { }
