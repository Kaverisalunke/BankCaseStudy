import { BnkserviceService } from '../bnkservice.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Http,Response } from '@angular/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transferamount',
  templateUrl: './transferamount.component.html',
  styleUrls: ['./transferamount.component.css'],
  providers:[BnkserviceService]
})
export class TransferamountComponent implements OnInit {

 
  amount:number;
  httpdata:any[];
  email:String;
  status:String;
  constructor(private iserve:BnkserviceService, private router:Router, private http:Http) { }
  ngOnInit() {
  }
onSubmit(form:NgForm){
      this.httpdata=this.iserve.transamount(this.email,this.amount);
      if(this.httpdata != null){
      let sta=this.httpdata[0]['status'];
      if(sta =='TRANSFFERED'){
        this.datadisplay();
      }
    }
  }
  btnClick=function(){
    this.router.navigateByUrl('/afterlogin');
  }
   datadisplay(){
    this.status="Amount Transfered Successfully";
    return this.status;
  }
}
