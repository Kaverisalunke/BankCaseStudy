//import { Component, OnInit } from '@angular/core';
//
//@Component({
//  selector: 'app-contactus',
//  templateUrl: './contactus.component.html',
//  styleUrls: ['./contactus.component.css']
//})
//export class ContactusComponent implements OnInit {
//  
//  name:String;
//  email:String;
//  mobile:String;
//  
//  message:String;
//  mModel:String;
//  constructor() { 
//  this.message=this.mModel;
//  }
//
//  fill(){
//    
//  }
//  
//  ngOnInit() {
//  }
// Clicked(event){
//   this.message="Message has been sent";
//   return this.message;
// }
//}



import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
