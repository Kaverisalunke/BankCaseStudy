import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class BnkserviceService {
  private myUrl = "http://localhost:8080/FinalCase/rest/bs/regist";
  private myUrl1 = "http://localhost:8080/FinalCase/rest/bs/ulogin";
  private myUrl2 = "http://localhost:8080/FinalCase/rest/bs/getStmt";
  private myUrl3 = "http://localhost:8080/FinalCase/rest/bs/insNum";
  private myUrl4 = "http://localhost:8080/FinalCase/rest/bs/chgPass";
  private myUrl5 = "http://localhost:8080/FinalCase/rest/bs/transamount";
  private myUrl6 = "http://localhost:8080/FinalCase/rest/bs/viewbal";
  private myUrl7 = "http://localhost:8080/FinalCase/rest/bs/viewANum";
// private myUrl8:"http://openlibrary.org/api/books?bibkeys=ISBN:0201558025,LCCN:93005405&format=json";
  amount: number;
  uname: String;
  name: String;
  username: String;
  password: String;
  email: String;
  oldnum: String;
  newnum: String;
  dob: Date;
  address: String;
  gender: String;
  npass: String;
  accno:String;


  httpdata: any[];
  
  constructor(private http: Http, private router: Router) {}
  
  register(name, username, password, email, mobile, dob, address, gender) {
    let s = this.myUrl + "/" + name + "/" + username + "/" + password + "/" + email + "/" + mobile + "/" + dob + "/" + address + "/" + gender;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    this.router.navigateByUrl('/login');
    return this.httpdata;

  }
  ulogin(username, password) {
    let s = this.myUrl1 + "/" + username + "/" + password;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));

    return this.httpdata;
  }
  getminsmt(email) {
    let s = this.myUrl2 + "/" + email;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }
  //  chngMobile(email, oldnum ,newnum) {
  //
  //    let s = this.myUrl3 + "/" + email + "/" +oldnum +"/"+newnum;
  //    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
  //    
  //    return this.httpdata; //
  //  }
  
  chngMobile(email, newnum) {

    let s = this.myUrl3 + "/" + email + "/" + newnum;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));

    return this.httpdata;

  }

  chngPassword(username, opass, npass) {

    let s = this.myUrl4 + "/" + username + "/" + opass + "/" + npass;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));

    return this.httpdata;

  }
  transamount(email, amount) {

    let s = this.myUrl5 + "/" + email + "/" + amount;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));

    return this.httpdata;

  }
  viewbal(email) {

    let s = this.myUrl6 + "/" + email;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;

  }


  viewaccno(username) {

    let s = this.myUrl7 + "/" + username;
//    this.http.get(s).map((response) => response.json()).subscribe((data) =>console.log(data));
    this.http.get(s).map((response) => response.json()).subscribe((data) =>this.displaydata(data));
    
    return this.httpdata;
  }
  
  
  

  displaydata(data) {this.httpdata = data;}
}
