import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  constructor() { }

      userName:String;
      oldpassword:String;
      newpassword:String;
      confirmpassword:String;
  ngOnInit() {
  }

  
   btnClick= function () {
        this.router.navigateByUrl('/forgotpassword');
};
  
}
