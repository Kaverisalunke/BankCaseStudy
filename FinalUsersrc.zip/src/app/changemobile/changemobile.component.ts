import { BnkserviceService } from '../bnkservice.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { Http } from '@angular/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-changemobile',
  templateUrl: './changemobile.component.html',
  styleUrls: ['./changemobile.component.css'],
  providers:[BnkserviceService]
})
export class ChangemobileComponent implements OnInit {
email:String;
  
  oldnum:String;
  newnum:String;
  httpdata:any[];
  status:String;
  
  
  constructor(private iserve:BnkserviceService, private router:Router, private http:Http) { }
onSubmit(){
   this.httpdata=this.iserve.chngMobile(this.email, this.newnum);
    
    if(this.httpdata != null){
      let sta=this.httpdata[0]['status'];
      if(sta =='success'){
//        this.router.navigateByUrl('/afterlogin');
        this.datadisplay();
     
      }
  }
  }
  ngOnInit() {
  }

  datadisplay(){
    this.status="Your request is pending";
    return this.status;
  }
  
  btnClick=function(){
    this.router.navigateByUrl('/afterlogin');
  }
}
