import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangemobileComponent } from './changemobile.component';

describe('ChangemobileComponent', () => {
  let component: ChangemobileComponent;
  let fixture: ComponentFixture<ChangemobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangemobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangemobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
