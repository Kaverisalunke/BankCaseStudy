import { BnkserviceService } from '../bnkservice.service';
import { Component, OnInit } from '@angular/core';
import {Http} from '@angular/http';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
httpdata:any[];
  data:any[];
  private url:"http://openlibrary.org/api/books?bibkeys=ISBN:0201558025,LCCN:93005405&format=json";
  //private url:"https://jsonplaceholder.typicode.com/todos/1";
  
  constructor( private iserve:BnkserviceService, private http:Http) { }

  

  ngOnInit() {

  }

}
