import { TestBed, inject } from '@angular/core/testing';

import { BnkserviceService } from './bnkservice.service';

describe('BnkserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BnkserviceService]
    });
  });

  it('should be created', inject([BnkserviceService], (service: BnkserviceService) => {
    expect(service).toBeTruthy();
  }));
});
