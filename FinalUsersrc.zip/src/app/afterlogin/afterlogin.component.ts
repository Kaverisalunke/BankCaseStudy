
import { Component, OnInit } from '@angular/core';
import { FormsModule } from'@angular/forms';
import { NgForm } from'@angular/forms';
import { Http } from '@angular/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-afterlogin',
  templateUrl: './afterlogin.component.html',
  styleUrls: ['./afterlogin.component.css'],
  
})
export class AfterloginComponent implements OnInit {

  constructor() { }
  
 
 
  ngOnInit() {
  }

}
