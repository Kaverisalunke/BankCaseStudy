
import { BnkserviceService } from '../bnkservice.service';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from'@angular/forms';
import { NgForm } from'@angular/forms';
import {Http,Response} from '@angular/http';
import {equal} from 'assert';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css'],
  providers:[BnkserviceService]
})
export class RegistrationComponent implements OnInit {

  name:String;
  username:String;
  password:String;
  email:String;
  mobile:String;
  dob:String;
  address:String;
  gender:String;
  httpdata:any[];
  status:String;
  btest:boolean;
  constructor(private iserve:BnkserviceService,private http:Http){}
  onSubmit(form:NgForm){
    this.httpdata=this.iserve.register(this.name,this.username,this.password,this.email,this.mobile,this.dob,this.address,this.gender);
  this.btest=true;
  }
  
  ngOnInit() {
  }

}
