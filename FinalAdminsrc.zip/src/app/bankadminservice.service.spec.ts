import { TestBed, inject } from '@angular/core/testing';

import { BankadminserviceService } from './bankadminservice.service';

describe('BankadminserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BankadminserviceService]
    });
  });

  it('should be created', inject([BankadminserviceService], (service: BankadminserviceService) => {
    expect(service).toBeTruthy();
  }));
});
