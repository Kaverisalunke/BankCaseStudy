import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-afteradminlogin',
  templateUrl: './afteradminlogin.component.html',
  styleUrls: ['./afteradminlogin.component.css'],
  
})
export class AfteradminloginComponent implements OnInit {

  constructor(private route:Router) { }
btnClick = function() {

  this.router.navigateByUrl('/login');
}
  
  ngOnInit() {}

}
