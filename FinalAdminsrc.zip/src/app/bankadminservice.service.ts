import {Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {Http, Response, HttpModule} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class BankadminserviceService {

  private myUrl1 = "http://localhost:8080/FinalCase/rest/adminserve/alogin";
  private myUrl2 = "http://localhost:8080/FinalCase/rest/adminserve/upmobile";
  private myUrl3 = "http://localhost:8080/FinalCase/rest/adminserve/vermobile";
  private myUrl4 = "http://localhost:8080/FinalCase/rest/adminserve/transamount";
  private myUrl5 = "http://localhost:8080/FinalCase/rest/adminserve/sendamount";
  private myUrl6 = "http://localhost:8080/FinalCase/rest/adminserve/viewbal";
  private myUrl7 = "http://localhost:8080/FinalCase/rest/adminserve/retView";

  
  
  
  

  username: String;
  password: String;
  email: String;
  mobile: String;
  amount: number;
  temail: String;
  amt: number;


  httpdata;
  constructor(private http: Http) {}

  alogin(username, password) {
    let s = this.myUrl1 + "/" + username + "/" + password;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }

  upmobile(email, mobile) {

    let s = this.myUrl2 + "/" + email + "/" + mobile;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data))
    return this.httpdata;
  }

  vermobile(email) {

    let s = this.myUrl3 + "/" + email;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }

  transamount(email, amount) {

    let s = this.myUrl4 + "/" + email + "/" + amount;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }

  sendamount(email, temail, amt) {

    let s = this.myUrl5 + "/" + email + "/" + temail + "/" + amt;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }

  viewbal(email) {

    let s = this.myUrl6 + "/" + email;
    this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
  }
  
  retview(){
   let s=this.myUrl7;
   this.http.get(s).map((response) => response.json()).subscribe((data) => this.displaydata(data));
    return this.httpdata;
 }

  displaydata(data) {this.httpdata = data;}
}
