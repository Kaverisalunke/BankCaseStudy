import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerifyrequestsComponent } from './verifyrequests.component';

describe('VerifyrequestsComponent', () => {
  let component: VerifyrequestsComponent;
  let fixture: ComponentFixture<VerifyrequestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerifyrequestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerifyrequestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
