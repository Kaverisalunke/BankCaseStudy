import { BankadminserviceService } from '../bankadminservice.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css'],
    providers: [BankadminserviceService]
})
export class DepositComponent implements OnInit {

  senderEmail:String;
  recieverEmail:String;
  amount:number;
httpdata: any[];   
  
  constructor(private iServe: BankadminserviceService, private router: Router) { }

  ngOnInit() {
  }
  
  onDeposit(form:NgForm){
  this.httpdata = this.iServe.sendamount(this.senderEmail,this.recieverEmail,this.amount);
  }

   btnClick=function(){
    this.router.navigateByUrl('/afteradminlogin');
  }
  
}
