import {BankadminserviceService} from '../bankadminservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {NgModule} from '@angular/core';
import {NgForm} from '@angular/forms';
import {Router} from '@angular/router';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-verifyrequests',
  templateUrl: './viewrequests.component.html',
  styleUrls: ['./viewrequests.component.css'],
  providers:[BankadminserviceService]
})
export class ViewrequestsComponent implements OnInit {

  email:String;
  newnum:String;

  httpdata:any[];
  
  constructor(private iserve:BankadminserviceService, private http:Http , private router:Router) { }

  onSubmit(event){
    this.httpdata=this.iserve.retview();
 }
  
  onClick(event){
   this.router.navigateByUrl('/verifyrequests');
  }
  
  ngOnInit() {
  }

  btnClick=function(){
    this.router.navigateByUrl('/afterlogin');
  }
  
}
