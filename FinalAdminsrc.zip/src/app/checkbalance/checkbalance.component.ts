import {BankadminserviceService} from '../bankadminservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {NgModule} from '@angular/core';
import {NgForm} from '@angular/forms';
import {Router} from '@angular/router';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-checkbalance',
  templateUrl: './checkbalance.component.html',
  styleUrls: ['./checkbalance.component.css'],
  providers:[BankadminserviceService]
})
export class CheckbalanceComponent implements OnInit {
  email:String;
  amount:number;
  httpdata:any[]; 
  constructor(private iServe: BankadminserviceService, private router: Router) { }

  
  onView(form:NgForm){
    this.httpdata = this.iServe.viewbal(this.email);

}
  ngOnInit() {
  }

}
