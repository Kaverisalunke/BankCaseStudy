import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';
import {Http, Response, HttpModule} from '@angular/http';
import 'rxjs/add/operator/map';

import {AppComponent} from './app.component';
import {LoginComponent} from './login/login.component';
import {FormsModule} from '@angular/forms';
import {AfteradminloginComponent} from './afteradminlogin/afteradminlogin.component';

import {VerifyrequestsComponent} from './verifyrequests/verifyrequests.component';
import {DepositComponent} from './deposit/deposit.component';
import {TransferComponent} from './transfer/transfer.component';
import {CheckbalanceComponent} from './checkbalance/checkbalance.component';
import { ViewrequestsComponent } from './viewrequests/viewrequests.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AfteradminloginComponent,
    VerifyrequestsComponent,
    DepositComponent,
    TransferComponent,
    CheckbalanceComponent,
    ViewrequestsComponent
  ],
  imports: [
    RouterModule.forRoot([
      {
        path: 'login',
        component: LoginComponent
      },
      {
        path: 'afteradminlogin',
        component: AfteradminloginComponent
      },
      {
        path: 'checkbalance',
        component: CheckbalanceComponent
      },
      {
        path: 'deposit',
        component: DepositComponent
      },
      {
        path: 'transfer',
        component: TransferComponent
      },
      {
        path: 'verifyrequests',
        component: VerifyrequestsComponent
      },
      {
        path: 'viewrequests',
        component: ViewrequestsComponent
      },
      
      {
        path: '',
        redirectTo: '/login', pathMatch: 'full'
      }



    ]),
    BrowserModule,
    FormsModule,
    HttpModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
