import {BankadminserviceService} from '../bankadminservice.service';
import {Component, OnInit} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {NgModule} from '@angular/core';
import {NgForm} from '@angular/forms';
import {Router} from '@angular/router';
import {Http, Response} from '@angular/http';
import 'rxjs/add/operator/map';


@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css'],
  providers: [BankadminserviceService]
})
export class TransferComponent implements OnInit {

  senderEmail:String;
  amount:number;
  httpdata: any[];   
  status:String;
  constructor(private iServe: BankadminserviceService, private router: Router) { }

  ngOnInit() {
  }

  onTransfer(form: NgForm){
    this.httpdata = this.iServe.transamount(this.senderEmail, this.amount);
if (this.httpdata != null) {
      let sta = this.httpdata[0]["status"];
      if (sta == "TRANSFFERED") {
      this.datadisplay();
      } 
  }
  }
  datadisplay(){
    this.status="Transferred successfully";
    return this.status;
  }
  
   btnClick=function(){
    this.router.navigateByUrl('/afteradminlogin');
  }
  
}